
import networkx as nx
import ndlib.models.ModelConfig as mc
import ndlib.models.epidemics.IndependentCascadesModel as ids
import matplotlib
import random
from bokeh.io import output_notebook, show
from ndlib.viz.bokeh.DiffusionTrend import DiffusionTrend
import ndlib.models.epidemics.ThresholdModel as th
import itertools
from operator import add
import pandas as pd

core_euemail="11 66 67 69 70 71 72 75 76 79 83 87 88 92 101 103 159 200 261 603 644 661 666 810 815 817 834 836 850 851 864 866 880 926 933 937 942 977 984 993 1001 1002 1004 1022 1032 1036 1038 1039 1046 1059 1060 1067 1072 1074 1091 1092 1115 1124 1134 1140 1147 1148 1150 1154 1157 1163 1165 1180 1181 1187 1196 1202 1203 1207 1217 1227 1228 1238 1291 1328 1350 1354 1357 1396 1540 1881 2065 2119 2176 2455 2519 2526 2527 2532 2545 2559 2566 2567 2575 2577 2581 2591 2595 2597 2934 3164 3598 3898 4370 4389 4399 4959 6641 7890 7966 8783 8908 27495"
core_euemail=set(core_euemail.split(" "))

truss_euemail="66 67 69 70 71 72 75 76 79 87 88 92 101 103 159 661 810 815 817 834 836 851 866 880 926 933 937 942 977 984 1001 1002 1036 1038 1039 1046 1059 1074 1091 1092 1115 1140 1148 1150 1181 1187 1203 1207 1217 1227 1291 1328 1354 1357 1396 1540 2065 2176 2519 2526 2545 2559 2566 2567 2575 2577 2581 2591 2595 2934 3598 4370 4389 4399 8783 8908 27495"

truss_euemail=set(truss_euemail.split(" "))

nuc_euemail = "11 66 67 70 71 72 75 76 79 87 88 92 101 103 159 661 810 815 817 834 836 851 866 880 933 977 984 1001 1002 1038 1039 1046 1059 1074 1091 1115 1140 1148 1150 1181 1187 1203 1207 1217 1227 1291 1328 1354 1540 2065 2176 2519 2526 2545 2559 2566 2567 2575 2581 3164 4370 4389 4399 8908 27495"

nuc_euemail=set(nuc_euemail.split(" "))


gg=[]


with open("/home/rragarwal/gt_models/slashdot_ps.txt", 'r') as f:
    next(f)
    for line in f:
        k=line.split()
        gg.append([k[0], k[1]])


g = nx.DiGraph()

g.add_edges_from(gg)


g2=g.to_undirected()

deg=nx.degree_centrality(g2)

deg= sorted(deg.items(), key=lambda kv: kv[1], reverse=True)

deg2=[x[0] for x in deg[:100]]



niter=1000
row=[[]]
all_m=[nuc_euemail, truss_euemail, core_euemail, deg2]

for trs in [ 0.1, 0.5, 1]:
    for sampsize in [1,5, 10, 20 , 45]:
        #print("#####")
        #print(sampsize)
        for dataset in all_m:
            res={}

            for i in range(niter):
                res[i+1]=[]

            for i in range(niter):
                kk=30
                model = th.ThresholdModel(g)
                T= set(random.sample(dataset, sampsize))
                #print(T)
                # Model Configuration
                config = mc.Configuration()
                config.add_model_initial_configuration("Infected", T )
                #config.add_model_parameter('percentage_infected', 0.001)

                # Setting the edge parameters

                for e in g.nodes():
                    config.add_node_configuration("threshold", e,  random.uniform(0, trs))
                    #config.add_node_configuration("threshold", e,  .96 )
                #print(config)

                model.set_initial_status(config)
                iterations = model.iteration_bunch(kk)
                for j in range(kk):
                    #print(iterations[j]["node_count"])
                    res[i+1].append(iterations[j]["status_delta"][1])
                    

            for l in range(1, niter+1):
                row.append([ l, all_m.index(dataset)+1, trs, sampsize]+res[l])

df=pd.DataFrame(row)

df.to_csv("/home/rragarwal/gt_models/slashdot_gt_ 005ab_1000.csv")
