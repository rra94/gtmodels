
import networkx as nx
import ndlib.models.ModelConfig as mc
import ndlib.models.epidemics.IndependentCascadesModel as ids
import matplotlib
import random
from bokeh.io import output_notebook, show
from ndlib.viz.bokeh.DiffusionTrend import DiffusionTrend
import ndlib.models.epidemics.ThresholdModel as th

import itertools
from operator import add
import pandas as pd

core_euemail="11 15 24 36 68 72 122 172 173 204 290 306 310 311 319 432 457 465 600 608 722 737 762 766 784 789 813 825 826 856 879 946 974 988 993 996 1062 1097 1098 1133 1137 1151 1166 1200 1210 1211 1247 1267 1297 1305 1319 1357 1374 1428 1470 1473 1492 1496 1521 1522 1537 1542 1549 1585 1608 1633 1688 1701 1717 1734 1754 1769 1799 1808 1814 1820 1847 1919 1922 1972 1990 2066 2114 2117 2118 2120 2134 2135 2144 2145 2174 2209 2210 2225 2237 2240 2251 2256 2257 2258 2276 2290 2297 2323 2324 2326 2328 2356 2364 2369 2371 2381 2384 2398 2411 2440 2474 2485 2504 2507 2508 2510 2516 2535 2542 2547 2560 2565 2576 2585 2593 2594 2595 2605 2619 2623 2625 2646 2651 2653 2654 2655 2657 2658 2660 2667 2674 2686 2688 2693 2696 2697 2700 2707 2713 2727 2746 2747 2774 2775 2790 2819 2822 2831 2842 2859 2871 2900 2909 2932 2940 2958 2967 2968 2972 2973 2981 3005 3007 3009 3010 3020 3024 3026 3027 3028 3032 3033 3034 3059 3084 3089 3092 3117 3125 3144 3148 3192 3238 3253 3258 3260 3265 3274 3276 3291 3321 3334 3352 3394 3404 3408 3417 3439 3443 3447 3449 3452 3453 3454 3455 3456 3458 3459 3473 3479 3480 3498 3537 3541 3562 3568 3586 3607 3614 3615 3631 3634 3635 3641 3642 3643 3645 3650 3660 3661 3666 3691 3724 3748 3787 3796 3812 3813 3843 3854 3897 3903 3910 3956 3958 3976 4011 4036 4037 4040 4041 4044 4045 4065 4073 4099 4124 4151 4162 4179 4191 4219 4247 4256 4297 4310 4335 4338 4400 4441 4448 4483 4536 4547 4574 4578 4587 4600 4632 4653 4666 4712 4717 4735 4792 4795 4824 4828 4899 4948 4964 4967 5002 5020 5022 5079 5123 5176 5178 5179 5188 5189 5226 5254 5262 5263 5412 5449 5459 5524 5543 5697 5714 5743 7632 8293"


core_euemail=set(core_euemail.split(" "))

truss_euemail="11 766 825 974 988 1166 1297 1305 1549 1972 2135 2145 2209 2237 2252 2290 2297 2324 2326 2328 2356 2398 2411 2474 2485 2510 2565 2576 2585 2594 2619 2625 2651 2653 2654 2657 2660 2667 2674 2686 2688 2693 2697 2700 2713 2727 2746 2747 2790 2859 2871 2958 2967 3005 3010 3024 3026 3028 3084 3117 3144 3148 3258 3260 3276 3352 3394 3404 3439 3454 3480 3529 3537 3562 3568 3615 3645 3650 3903 4256"

truss_euemail=set(truss_euemail.split(" "))


nuc_euemail ="766 825 988 1166 1305 1549 2209 2237 2252 2290 2297 2328 2411 2485 2510 2565 2651 2653 2654 2657 2660 2674 2686 2688 2693 2700 2713 2747 2958 3005 3010 3024 3026 3028 3148 3352 3529"

nuc_euemail=set(nuc_euemail.split(" "))

#truss_euemail= truss_euemail-nuc_euemail

#core_euemail = core_euemail- truss_euemail

#core_euemail = core_euemail - nuc_euemail


#print(len(core_euemail))
#print(len(truss_euemail))
#print(len(nuc_euemail))

n=8297



gg=[]


with open("/home/rragarwal/gt_models/wikivote_ps.txt", 'r') as f:
    next(f)
    for line in f:
        k=line.split()
        gg.append([k[0], k[1]])


g = nx.DiGraph()

g.add_edges_from(gg)


g2=g.to_undirected()

deg=nx.degree_centrality(g2)

deg= sorted(deg.items(), key=lambda kv: kv[1], reverse=True)

deg2=[x[0] for x in deg[:200]]

deg2 = set(deg2)

#deg2= deg2-nuc_euemail

#deg2=deg2-truss_euemail

#deg2=deg2-core_euemail

#print(len(deg2))

niter=1000
row=[[]]
all_m=[nuc_euemail, truss_euemail, core_euemail, deg2]

for trs in [0.1, 0.5, 1]:
    for sampsize in [1,5, 10,20, 35]:
        #print("#####")
        #print(sampsize)
        for dataset in all_m:
            res={}

            for i in range(niter):
                res[i+1]=[]

            for i in range(niter):
                kk=30
                #model = ids.IndependentCascadesModel(g)
                model = th.ThresholdModel(g)
                T= set(random.sample(dataset, sampsize))
                #print(T)
                # Model Configuration
                config = mc.Configuration()
                config.add_model_initial_configuration("Infected", T )
                #config.add_model_parameter('percentage_infected', 0.001)

                # Setting the edge parameters

                for e in g.nodes():
                    config.add_node_configuration("threshold", e,  random.uniform(0, trs))
                    #config.add_edge_configuration("threshold", e,  .96 )
                #print(config)

                model.set_initial_status(config)
                iterations = model.iteration_bunch(kk)
                for j in range(kk):
                    #print(iterations[j]["node_count"])
                    res[i+1].append(iterations[j]["status_delta"][1])
                    
            #r=res[1]

            #for l in range(2,niter+1):
            #    r=list( map(add, r, res[l]) )

           # r= [x / niter for x in r]
            #print(r)
            for l in range(1, niter+1):
                row.append([ l, all_m.index(dataset)+1, trs, sampsize]+res[l])

df=pd.DataFrame(row)

df.to_csv("/home/rragarwal/gt_models/wikivote_gt_005ab_1000.csv")
