
import networkx as nx
import ndlib.models.ModelConfig as mc
import ndlib.models.epidemics.IndependentCascadesModel as ids
import matplotlib
import random
from bokeh.io import output_notebook, show
from ndlib.viz.bokeh.DiffusionTrend import DiffusionTrend
import ndlib.models.epidemics.ThresholdModel as th
import itertools
from operator import add
import pandas as pd

core_euemail="1 10 11 20 34 35 41 50 68 79 86 104 106 111 120 126 134 135 146 147 149 158 167 175 178 182 186 192 195 202 203 207 209 217 233 240 242 248 252 256 259 261 264 287 289 290 292 298 299 301 302 314 327 328 332 333 336 337 349 356 372 388 390 392 397 406 417 422 425 431 433 435 439 440 441 442 446 452 455 457 467 493 500 505 509 510 512 516 534 535 536 562 589 590 599 602 615 620 622 623 626 631 640 663 664 668 673 676 677 685 693 694 697 704 714 715 760 779 784 794 801 805 808 809 810 818 838 841 843 849 852 862 868 872 907 911 918 920 929 932 949 968 972 973 1001 1010 1011 1014 1033 1085 1089 1118 1119 1130 1133 1140 1147 1151 1172 1179 1181 1191 1192 1204 1210 1220 1222 1231 1240 1262 1267 1276 1282 1284 1285 1293 1298 1309 1326 1332 1345 1368 1370 1381 1402 1417 1425 1445 1454 1462 1515 1518 1522 1531 1559 1564 1566 1572 1619 1623 1634 1655 1659 1663 1715 1722 1732 1749 1782 1796 1805 1818 1837 1844 1849 1893 1955 1973 1992 2083 2173 2205 2244 2253 2373 2512 2620 2689 2775 2979 2991 3392 3422 3507 3524 3804 3866 4039 4066 4190 4276 4771 6119 6247 6824 6904 7087 7827 8296 8344 9457 13207 14092 19413 21442 21795 24704 33424 33707 33747 39618 41687 47181 47681 58820 66227 73693 75912 77198 83504 92476 94134 114962 118331 118336 127158 135145 149675 172620 175348 182166 182193 183629 189054 189055 204280 215874 220695 224327 229957 246187 260372"



core_euemail=set(core_euemail.split(" "))

# truss_euemail= "246 2643 2647 2648 2651 2655 2666 2676 2693 2723 2735 2750 6651 6661 9679 9693 9695 9699 9708 9710 9719 9740 9744 9868 9869 9870 9875 9876 9879 9881 9883 9885 9886 9889 9891 9892 9897 9900 9901 9904 9906 9908 9911 9914 9919 9923 9926 9927 9928 9930 9932 9939 9941 9946 9952 9962 9965 9967 9968 9976 9983 9986 10000"

truss_euemail ="17 50 1244 1253 1306 1313 154907 154908"


"2 107 160 392 617 1387 1525 1663 2088 2408 2815 4152 4154 4786 6414 6990 7412 8017 8661 8875 9782 10037 11256 11469 11713 12231 12388"

# 126 167 182 192 207 240 256 259 264 301 302 314 336 392 397 441 452 457 467 510 516 536 599 673 676 685 794 818 838 843 849 852 872 911 918 972 1010 1011 1014 1085 1118 1130 1147 1172 1191 1204 1210 1293 1326 1345 1370 1417 1518 1531 1566 1655 1663 1796 1844 1992 2373 75912"

truss_euemail=set(truss_euemail.split(" "))


nuc_euemail=  "7 8 220 492 1003 1031 1056 1057 1065 1066 1071 1073 1091 17 50 1244 1253 1306 1313 154907 154908"

"92 107 160 392 617 1387 1525 1663 2088 2408 2815 4152 4154 4786 6414 6990 7412 8017 8661 8875 9782 10037 11256 11469 11713 12231 12388"
# nuc_euemail ="246 2643 2647 2648 2651 2655 2666 2676 2693 2723 2735 2750 6651 6661 9679 9693 9695 9699 9708 9710 9719 9740 9868 9869 9876 9879 9881 9883 9885 9886 9889 9891 9892 9897 9901 9904 9906 9911 9914 9919 9926 9927 9928 9930 9932 9939 9946 9952 9968 9976 9983 9986"

#  "1 50 146 147 149 158 175 195 336 406 505 640 779 1425 1515 92476 118336 167 182 192 240 264 301 314 392 397 452 457 467 510 516 536 599 673 794 818 838 843 849 872 1010 1011 1014 1085 1118 1130 1204 1210 1370 1417 1518 1531 1566 1796 1844 75912"

nuc_euemail=set(nuc_euemail.split(" "))


#truss_euemail= truss_euemail-nuc_euemail

#core_euemail = core_euemail- truss_euemail

#core_euemail = core_euemail - nuc_euemail



n=265215
gg=[]


with open("/home/rragarwal/gt_models/Email-EuAll.txt", 'r') as f:
    next(f)
    for line in f:
        k=line.split()
        gg.append([k[0], k[1]])


g = nx.DiGraph()

g.add_edges_from(gg)


g2=g.to_undirected()

deg=nx.degree_centrality(g2)

deg= sorted(deg.items(), key=lambda kv: kv[1], reverse=True)

deg2=[x[0] for x in deg[:100]]


#deg2 = set(deg2)

#deg2= deg2-nuc_euemail

#deg2=deg2-truss_euemail

#deg2=deg2-core_euemail

niter=1000
row=[[]]
all_m=[nuc_euemail, truss_euemail, core_euemail, deg2]

for trs in [ 0.1, 0.5,1]:
    for sampsize in [1,5, 10, 20, 45]:
        #print("#####")
        #print(sampsize)
        for dataset in all_m:
            res={}

            for i in range(niter):
                res[i+1]=[]

            for i in range(niter):
                kk=30
                model = th.ThresholdModel(g)
                T= set(random.sample(dataset, sampsize))
                #print(T)
                # Model Configuration
                config = mc.Configuration()
                config.add_model_initial_configuration("Infected", T )
                #config.add_model_parameter('percentage_infected', 0.001)

                # Setting the edge parameters

                for e in g.nodes():
                    config.add_node_configuration("threshold", e,  random.uniform(0, trs))
                    #config.add_edge_configuration("threshold", e,  .96 )
                #print(config)

                model.set_initial_status(config)
                iterations = model.iteration_bunch(kk)
                for j in range(kk):
                    #print(iterations[j]["node_count"])
                    res[i+1].append(iterations[j]["status_delta"][2])
                    
            for l in range(1, niter+1):
                row.append([ l, all_m.index(dataset)+1, trs, sampsize]+res[l])

df=pd.DataFrame(row)


df.to_csv("/home/rragarwa/gt_models/euemail_gt_005ab_1000.csv")
